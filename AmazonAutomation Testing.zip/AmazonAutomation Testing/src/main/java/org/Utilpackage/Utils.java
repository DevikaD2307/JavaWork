package org.Utilpackage;

public class Utils
{
public static long PAGE_LOAD_TIMEOUTS=20;
public static long IMPLICIT_WAIT=10;
}
