package org.PageClassPackage;

public class LaunchingPage {
}
